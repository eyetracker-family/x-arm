'''
Created on Jul 7, 2016

@author: brunsc
'''

# Programatically run as if "nosetests" on command line
import nose
nose.main()
